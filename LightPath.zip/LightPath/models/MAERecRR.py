# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# timm: https://github.com/rwightman/pytorch-image-models/tree/master/timm
# DeiT: https://github.com/facebookresearch/deit
# --------------------------------------------------------
from layers.weight_init import trunc_normal_
from functools import partial
from layers.patch_embed import PatchEmbed, PositionEmbed
import torch
import torch.nn as nn

from timm.models.vision_transformer import Block

from utils.pos_embed import get_2d_sincos_pos_embed


class MaskedAutoencoderViT(nn.Module):
    """ Masked Autoencoder with VisionTransformer backbone
    """
    def __init__(self, 
                 node2vec,
                 time2vec,
                 # moving_average_decay,
                 # beta,
                 # projection_size,
                 # projection_hidden_size,
                 # prediction_hidden_size,
                 # prediction_size,
                 num_patches=100, in_chans=3,
                 embed_dim=1024, depth=24, num_heads=16,
                 decoder_embed_dim=512, decoder_depth=8, decoder_num_heads=16,
                 mlp_ratio=4., embed_layer=PatchEmbed, norm_layer=partial(nn.LayerNorm, eps=1e-6), norm_pix_loss=False):
        super().__init__()

        # --------------------------------------------------------------------------
        # MAE encoder specifics
        self.patch_embed = embed_layer(node2vec=node2vec, time2vec=time2vec, embed_dim=128, dropout=0.)

        # self.patch_embed = PatchEmbed(img_size, patch_size, in_chans, embed_dim)
        num_patches = num_patches
        self.num_classes=3

        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, embed_dim), requires_grad=False)  # fixed sin-cos embedding

        self.blocks = nn.ModuleList([
            Block(embed_dim, num_heads, mlp_ratio, qkv_bias=True, qk_scale=None, norm_layer=norm_layer)
            for i in range(depth)])
        self.norm = norm_layer(embed_dim)
        # --------------------------------------------------------------------------

        # --------------------------------------------------------------------------
        # MAE decoder specifics
        self.decoder_embed = nn.Linear(embed_dim, decoder_embed_dim, bias=True)

        self.mask_token = nn.Parameter(torch.zeros(1, 1, decoder_embed_dim))

        self.decoder_pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, decoder_embed_dim), requires_grad=False)  # fixed sin-cos embedding

        self.decoder_blocks = nn.ModuleList([
            Block(decoder_embed_dim, decoder_num_heads, mlp_ratio, qkv_bias=True, qk_scale=None, norm_layer=norm_layer)
            for i in range(decoder_depth)])

        self.decoder_norm = norm_layer(decoder_embed_dim)
        # self.decoder_pred = nn.Linear(decoder_embed_dim, patch_size**2 * in_chans, bias=True) # decoder to patch
        # --------------------------------------------------------------------------

        self.relation_head = torch.nn.Sequential(
                             torch.nn.Linear(128*2, 128),  ###change 2 to 4
                             torch.nn.BatchNorm1d(128),
                             torch.nn.LeakyReLU(),
                             torch.nn.Linear(128, 1))
        self.norm_pix_loss = norm_pix_loss
        self.criterion_bce = nn.BCEWithLogitsLoss()
        self.criterion_cls = nn.CrossEntropyLoss()

        self.clstoken =nn.Linear(128*2,3)
        self.acf = nn.ReLU()

        self.apply(self._init_vit_weights)

    def _init_vit_weights(self, module):
        """ ViT weight initialization
        """
        if isinstance(module, nn.Linear):
            if module.out_features == self.num_classes:
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            else:
                trunc_normal_(module.weight, std=.02)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)             
        elif isinstance(module, (nn.LayerNorm, nn.GroupNorm, nn.BatchNorm2d)):
            nn.init.zeros_(module.bias)
            nn.init.ones_(module.weight)


    def random_masking(self, x, mask_ratio):
        """
        Perform per-sample random masking by per-sample shuffling.
        Per-sample shuffling is done by argsort random noise.
        x: [N, L, D], sequence
        """
        N, L, D = x.shape  # batch, length, dim
        len_keep = int(L * (1 - mask_ratio))
        
        noise = torch.rand(N, L, device=x.device)  # noise in [0, 1]
        
        # sort noise for each sample
        ids_shuffle = torch.argsort(noise, dim=1)  # ascend: small is keep, large is remove
        ids_restore = torch.argsort(ids_shuffle, dim=1)

        # keep the first subset
        ids_keep = ids_shuffle[:, :len_keep]
        x_masked = torch.gather(x, dim=1, index=ids_keep.unsqueeze(-1).repeat(1, 1, D))

        # generate the binary mask: 0 is keep, 1 is remove
        mask = torch.ones([N, L], device=x.device)
        mask[:, :len_keep] = 0
        # unshuffle to get the binary mask
        mask = torch.gather(mask, dim=1, index=ids_restore)

        return x_masked, mask, ids_restore

    def forward_encoder(self, x,ts, mask_ratio):
        # embed patches
        x, ts_ = self.patch_embed(x, ts)
        xx=x

        # add pos embed w/o cls token
        x = x + self.pos_embed[:, 1:, :]

        # masking: length -> length * mask_ratio
        x, mask, ids_restore = self.random_masking(x, mask_ratio)

        # append cls token
        cls_token = self.cls_token + self.pos_embed[:, :1, :]
        cls_tokens = cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)

        # apply Transformer blocks
        for blk in self.blocks:
            x = blk(x)
        x = self.norm(x)

        return x, mask, ids_restore,xx, ts_

    def forward_decoder(self, x, ids_restore):
        # embed tokens
        x = self.decoder_embed(x)

        # append mask tokens to sequence
        mask_tokens = self.mask_token.repeat(x.shape[0], ids_restore.shape[1] + 1 - x.shape[1], 1)
        x_ = torch.cat([x[:, 1:, :], mask_tokens], dim=1)  # no cls token
        x_ = torch.gather(x_, dim=1, index=ids_restore.unsqueeze(-1).repeat(1, 1, x.shape[2]))  # unshuffle
        x = torch.cat([x[:, :1, :], x_], dim=1)  # append cls token

        # add pos embed
        x = x + self.decoder_pos_embed

        # apply Transformer blocks
        for blk in self.decoder_blocks:
            x = blk(x)
        x = self.decoder_norm(x)

        # predictor projection
        # x = self.decoder_pred(x)

        # remove cls token
        x = x[:, 1:, :]

        return x

    def forward_loss(self, x, pred, mask):
        """
        imgs: [N, 3, H, W]
        pred: [N, L, p*p*3]
        mask: [N, L], 0 is keep, 1 is remove, 
        """
        # target = self.patchify(imgs)
        # if self.norm_pix_loss:
        #     mean = target.mean(dim=-1, keepdim=True)
        #     var = target.var(dim=-1, keepdim=True)
        #     target = (target - mean) / (var + 1.e-6)**.5

        loss = (pred - x) ** 2
        loss = loss.mean(dim=-1)  # [N, L], mean loss per patch

        loss = (loss * mask).sum() / mask.sum()  # mean loss on removed patches
        return loss

    def forward(self, intputs, ts, targets, mask_ratio1=0.7, mask_ratio2=0.8):
        
        latent1, mask1, ids_restore1, xx1, ts1 = self.forward_encoder(intputs,ts, mask_ratio1)
        latent2, mask2, ids_restore2, xx2, ts2 = self.forward_encoder(intputs,ts, mask_ratio2)
        
        pred1 = self.forward_decoder(latent1, ids_restore1)  # [N, L, p*p*3]
        pred2 = self.forward_decoder(latent2, ids_restore2)  # [N, L, p*p*3]
        
        cls_token_1 = latent1[:, 0, :]
        cls_token_2 = latent2[:, 0, :]

        # cls_token_rr1 = torch.cat([cls_token_1, torch.squeeze(ts1[:,0,:],1)],1)
        # cls_token_rr2 = torch.cat([cls_token_2, torch.squeeze(ts2[:,0,:],1)],1)
        # #####CLS
        cls_token_c1 = self.acf(self.clstoken(torch.cat([cls_token_1, torch.squeeze(ts1[:,0,:],1)],1)))
        cls_token_c2 = self.acf(self.clstoken(torch.cat([cls_token_2, torch.squeeze(ts2[:,0,:],1)],1)))

        # ###peak offpeak classification
        # loss_cls1 =self.criterion_cls(torch.squeeze(cls_token_c1, 1),targets)
        # loss_cls2 =self.criterion_cls(torch.squeeze(cls_token_c2, 1),targets)
        # loss_cls = 0.5*(loss_cls1 + loss_cls2)

        ####Rec
        loss_rec1 = self.forward_loss(xx1, pred1, mask1)
        loss_rec2 = self.forward_loss(xx2, pred2, mask2)
        loss_rec = 0.5*(loss_rec1 + loss_rec2)

        #####RR
        
        cls_feature_rr = torch.cat([cls_token_1, cls_token_2],0) 
        relation_pairs, targets_rr, scores = self.aggregate(cls_feature_rr, K=2)
        if torch.cuda.is_available():
            scores = scores.cuda()
            targets_rr = targets_rr.cuda()
        loss_rr   =self.criterion_bce(torch.squeeze(scores,1), targets_rr)

        return loss_rec, loss_rec, loss_rr, pred1, mask1, pred2, mask2

    def aggregate(self, features, K=2):
        relation_pairs_list = list()
        targets_list = list()
        size = int(features.shape[0] / K)
        shifts_counter=1
        for index_1 in range(0, size*K, size):
            for index_2 in range(index_1+size, size*K, size):
                # Using the 'cat' aggregation function by default
                pos_pair = torch.cat([features[index_1:index_1+size], 
                              features[index_2:index_2+size]], 1)
                # Shuffle without collisions by rolling the mini-batch (negatives)
                neg_pair = torch.cat([
                     features[index_1:index_1+size], 
                     torch.roll(features[index_2:index_2+size], 
                     shifts=shifts_counter, dims=0)], 1)
                relation_pairs_list.append(pos_pair)
                relation_pairs_list.append(neg_pair)
                targets_list.append(torch.ones(size, dtype=torch.float32))
                targets_list.append(torch.zeros(size, dtype=torch.float32))
                shifts_counter+=1
                if(shifts_counter>=size): 
                    shifts_counter=1 # avoid identity pairs
        relation_pairs = torch.cat(relation_pairs_list, 0)
        targets = torch.cat(targets_list, 0)
        # print(relation_pairs.size())
        return relation_pairs, targets, self.relation_head(relation_pairs)
    
    def embed(self, intputs, ts, mask_ratio=0.75):
        latent, _,_,_, _= self.forward_encoder(intputs, ts, mask_ratio)
   
        return latent[:,0,:]

def mae_vit_base_patch16_dec512d8b(**kwargs):
    model = MaskedAutoencoderViT(
        patch_size=16, embed_dim=768, depth=12, num_heads=12,
        decoder_embed_dim=512, decoder_depth=8, decoder_num_heads=16,
        mlp_ratio=4, norm_layer=partial(nn.LayerNorm, eps=1e-6), **kwargs)
    return model

def mae_vit_large_patch16_dec512d8b(**kwargs):
    model = MaskedAutoencoderViT(
        patch_size=16, embed_dim=1024, depth=24, num_heads=16,
        decoder_embed_dim=512, decoder_depth=8, decoder_num_heads=16,
        mlp_ratio=4, norm_layer=partial(nn.LayerNorm, eps=1e-6), **kwargs)
    return model

def mae_vit_huge_patch14_dec512d8b(**kwargs):
    model = MaskedAutoencoderViT(
        patch_size=14, embed_dim=1280, depth=32, num_heads=16,
        decoder_embed_dim=512, decoder_depth=8, decoder_num_heads=16,
        mlp_ratio=4, norm_layer=partial(nn.LayerNorm, eps=1e-6), **kwargs)
    return model