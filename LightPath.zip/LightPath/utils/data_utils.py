
import numpy as np
import torch
import pickle
import os
from collections import namedtuple

def argsort(seq):
    """
    sort by length in reverse order
    ---
    seq (list[array[int32]])
    """
    return [x for x,y in sorted(enumerate(seq),
                                key = lambda x: len(x[1]),
                                reverse=True)]

def pad_array(a, max_length, PAD=8893):
    """
    a (array[int32])
    """
    return np.concatenate((a, [PAD]*(max_length - len(a))))

def pad_arrays(a):
    max_length = 100#max(map(len, a))
    a = [pad_array(a[i], max_length) for i in range(len(a))]
    a = np.stack(a).astype(np.int)
    return torch.LongTensor(a)

class SlotData():
    def __init__(self, trips, ts, yc, yt, minlen=1):
        """
        trips (n, *): each element is a sequence of road segments
        times (n, ): each element is a travel cost
        """
        ## filter out the trips that are too long
        # idx = [i for (i, trip) in enumerate(trips) if len(trip) <= maxlen]
        idx = [i for (i, trip) in enumerate(trips) if len(trip) >= minlen]
        self.trips = trips[idx]
        self.ts = ts[idx]
        self.yc = yc[idx]
        self.yt = yt[idx]
        # idx = argsort(trips)
        # self.trips = self.trips[idx]
        # self.yc = torch.tensor(self.yc[idx], dtype=torch.int64)
        self.yc = torch.LongTensor(self.yc)
        self.ts = torch.LongTensor(self.ts)
        self.yt = torch.tensor(self.yt, dtype=torch.float32)
        # self.distances = torch.tensor(self.distances[idx], dtype=torch.float32)

        self.ntrips = len(self.trips)
        self.start = 0


    def random_emit(self, batch_size):
        """
        Input:
          batch_size (int)
        ---
        Output:
          SD.trips (batch_size, seq_len)
          SD.times (batch_size,)
          SD.ratios (batch_size, seq_len)
          SD.S (num_channel, height, width)
        """
        SD = namedtuple('SD', ['trips', 'traffic','times', 'labels'])
        start = np.random.choice(max(1, self.ntrips-batch_size+1))
        end = min(start+batch_size, self.ntrips)

        trips = pad_arrays(self.trips[start:end])
        ts = self.ts[start:end]
        yt = self.yt[start:end]
        yc = self.yc[start:end]
        return SD(trips=trips, traffic = ts, times=yt, labels=yc)

    def order_emit(self, batch_size):
        """
        Reset the `start` every time the current slot has been traversed
        and return none.
        Input:
          batch_size (int)
        ---
        Output:
          SD.trips (batch_size, seq_len)
          SD.times (batch_size,)
          SD.ratios (batch_size, seq_len)
          SD.S (num_channel, height, width)
        """
        if self.start >= self.ntrips:
            self.start = 0
            return None
        SD =  namedtuple('SD', ['trips', 'traffic','times', 'labels'])
        start = self.start
        end = min(start+batch_size, self.ntrips)
        self.start += batch_size

        trips = pad_arrays(self.trips[start:end])
        ts = self.ts[start:end]
        yt = self.yt[start:end]
        yc = self.yc[start:end]
        return SD(trips=trips, traffic=ts, times=yt, labels=yc)



class DataLoader():
    # def __init__(self, trainpath, num_slot=71):
    def __init__(self, trainpath):
        """
        trainpath (string): The h5file path
        num_slot (int): The number of slots in a day
        """
        self.trainpath = trainpath
        # self.num_slot = num_slot
        self.slotdata_pool = []
        ## `weights[i]` is proportional to the number of trips in `slotdata_pool[i]`
        self.weights = None
        ## The length of `slotdata_pool`
        self.length = 0
        ## The current index of the order emit
        self.order_idx = -1

    def read_file(self, fname):
        """
        Reading one h5file and appending the data into `slotdata_pool`. This function
        should only be called by `read_files()`.
        """
        x1, ts, yc, yt = pickle.load(open(fname, 'rb'))
        self.slotdata_pool.append(
                    SlotData(np.array(x1), np.array(ts), np.array(yc), np.array(yt)))

    def read_files(self, fname_lst):
        """
        Reading a list of pkl files and appending the data into `slotdata_pool`.
        """
        for fname in fname_lst:
            fname = os.path.basename(fname)
            print("Reading {}...".format(fname))
            self.read_file(os.path.join(self.trainpath, fname))
            print("Done.")
        self.weights = np.array(list(map(lambda s:s.ntrips, self.slotdata_pool)))
        self.weights = self.weights / np.sum(self.weights)
        self.length = len(self.weights)
        self.order = np.random.permutation(self.length)
        self.order_idx = 0

    def random_emit(self, batch_size):
        """
        Return a batch of data randomly.
        """
        i = np.random.choice(self.length, p=self.weights)
        return self.slotdata_pool[i].random_emit(batch_size)

    def order_emit(self, batch_size):
        """
        Visiting the `slotdata_pool` according to `order` and returning the data in the
        slot `slotdata_pool[i]` orderly.
        """
        i = self.order[self.order_idx]
        data = self.slotdata_pool[i].order_emit(batch_size)
        if data is None: ## move to the next slot
            self.order_idx += 1
            if self.order_idx >= self.length:
                self.order_idx = 0
                self.order = np.random.permutation(self.length)
            i = self.order[self.order_idx]
            data = self.slotdata_pool[i].order_emit(batch_size)
        return data

if __name__ == '__main__':

    trainpath = './Aalborg_New/data/'
    trainfiles = list(filter(lambda x:x.endswith(".pkl"),
                            sorted(os.listdir(trainpath))))
    print(trainfiles)
    # trainfiles = './Aalborg_New/data_DT211216_Aalborg_MAE_Train_DLen.pkl'
    train_dataloader = DataLoader(trainpath)
    train_dataloader.read_files(trainfiles)
    train_slot_size = np.array(list(map(lambda s:s.ntrips, train_dataloader.slotdata_pool)))
    train_num_iterations = int(np.ceil(train_slot_size/32).sum())
    print("There are {} trips in the training dataset".format(train_slot_size.sum()))
    print("Number of iterations for an epoch: {}".format(train_num_iterations))

    data = train_dataloader.order_emit(4)
    print(data.trips)
    for i in range(len(data.trips)):
        print(len(data.trips[i]))
    print(data.times)
    print(data.labels)
