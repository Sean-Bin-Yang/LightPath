import torch
import numpy as np
import math
import time

def LogitsLoss(l1,l2):
    b_xent = torch.nn.BCEWithLogitsLoss()
    loss_ = b_xent(l1,l2)
    return loss_


def cal_performance(res_pos,res_neg):
    
    loss = mi_loss_jsd(res_pos,res_neg)

    return loss

def mi_loss_jsd(pos,neg):
    e_pos = torch.mean(sp_func(-pos))
    e_neg = torch.mean(torch.mean(sp_func(neg),0))
    return e_pos + e_neg

def sp_func(arg):
    return torch.log(1+torch.exp(arg))


def mask_enc(input):
    src_mask = []
    for i in range(len(input)):
        submask = []
        for j in range(len(input[i])):
            subsubmask =[]
            if input[i][j] == 8893:
                subsubmask.append(1)
            else:
                subsubmask.append(0)
            submask.append(subsubmask)
        src_mask.append(submask)
    return src_mask


def mask_pad(input):
    src_mask = []
    for i in range(len(input)):
        submask = []
        for j in range(len(input[i])):
            subsubmask =[]
            if input[i][j] == 8893:
                subsubmask.append(0)
            else:
                subsubmask.append(1)
            submask.append(subsubmask)
        src_mask.append(submask)
    return src_mask

def print_performances_single(header, epoch, loss, start_time):
    print('  - {header:12} epoch: {epoch: d}, ppl1: {ppl1: 8.5f}, '\
            'elapse: {elapse: 3.3f} '.format(
                header=f"({header})", epoch=epoch, ppl1=loss,
            elapse=(time.time()-start_time)/60))

def print_performances_multi(header, epoch, loss, loss1, loss2, start_time):
    print('  - {header:12} epoch: {epoch: d}, loss: {loss: 8.5f}, loss_cls:{loss_cls: 8.5f}, loss_rec:{loss_rec: 8.5f}, '\
            'elapse: {elapse: 3.3f} '.format(header=f"({header})", epoch=epoch, loss=loss, loss_cls=loss1, loss_rec = loss2,
                elapse=(time.time()-start_time)/60))

# def unmask_mean(input):
#     size1 = input.size(0)
#     size2 = input.size(1)
#     output = []
#     for i in range(size1):
#         suboutput = []
#         for j in range(size2):
#             if torch.mean(input[i, j, :]) != 0:
#                 suboutput.append(input[i, j, :])
#         output.append(np.mean(suboutput, axis=0))
#         output.append(torch.mean(torch.stack(suboutput,0),axis=0))
#     return torch.unsqueeze(torch.stack(output,0), 1) ###Batch_size, 1, dimension
